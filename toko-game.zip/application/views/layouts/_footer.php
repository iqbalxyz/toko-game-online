<footer class="footer mt-5">
	<nav class="navbar navbar-dark bg-light sticky-bottom">
		<div class="container d-flex justify-content-center">
			<div class="copyright text-info p-3">
				<small class="text-info p-3">Web Programming Universitas Nusa Mandiri 2023</small>
			</div>
		</div>
	</nav>	
</footer>  
